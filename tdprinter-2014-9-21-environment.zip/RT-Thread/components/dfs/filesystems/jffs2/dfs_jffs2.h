#ifndef __DFS_JFFS2_H__ 
#define __DFS_JFFS2_H__

int dfs_jffs2_init(void);

#endif
