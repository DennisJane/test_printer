#ifndef __INTTYPES_H__
#define __INTTYPES_H__

#include "stdint.h"

#endif
